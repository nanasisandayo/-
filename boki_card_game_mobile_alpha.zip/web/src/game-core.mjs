export const ACCOUNT_DEFS = {
  現金: ['資産', '借方'], 普通預金: ['資産', '借方'], 当座預金: ['資産', '借方'], 小口現金: ['資産', '借方'], 現金過不足: ['資産', '借方'],
  売掛金: ['資産', '借方'], 受取手形: ['資産', '借方'], 電子記録債権: ['資産', '借方'], 貸付金: ['資産', '借方'], 未収入金: ['資産', '借方'], 前払金: ['資産', '借方'], 仮払金: ['資産', '借方'], 立替金: ['資産', '借方'], 商品: ['資産', '借方'], 備品: ['資産', '借方'], 建物: ['資産', '借方'], 土地: ['資産', '借方'], 減価償却累計額: ['資産', '貸方'], 貸倒引当金: ['資産', '貸方'],
  買掛金: ['負債', '貸方'], 支払手形: ['負債', '貸方'], 電子記録債務: ['負債', '貸方'], 借入金: ['負債', '貸方'], 未払金: ['負債', '貸方'], 前受金: ['負債', '貸方'], 仮受金: ['負債', '貸方'], 預り金: ['負債', '貸方'],
  資本金: ['純資産', '貸方'], 繰越利益剰余金: ['純資産', '貸方'],
  売上: ['収益', '貸方'], 受取手数料: ['収益', '貸方'], 受取利息: ['収益', '貸方'], 雑収入: ['収益', '貸方'],
  仕入: ['費用', '借方'], 給料: ['費用', '借方'], 広告宣伝費: ['費用', '借方'], 旅費交通費: ['費用', '借方'], 通信費: ['費用', '借方'], 消耗品費: ['費用', '借方'], 水道光熱費: ['費用', '借方'], 支払家賃: ['費用', '借方'], 支払地代: ['費用', '借方'], 支払利息: ['費用', '借方'], 租税公課: ['費用', '借方'], 貸倒損失: ['費用', '借方'], 減価償却費: ['費用', '借方'], 売上原価: ['費用', '借方'],
};

export const CATEGORIES = ['資産', '負債', '純資産', '収益', '費用'];

export function rollAmount(d1, d2) {
  if (!Number.isInteger(d1) || d1 < 1 || d1 > 10) throw new Error('1個目のサイコロは1〜10です');
  if (!Number.isInteger(d2) || d2 < 1 || d2 > 4) throw new Error('2個目のサイコロは1〜4です');
  return d1 * d2 * 1000;
}

export function normalSide(category) {
  return category === '資産' || category === '費用' ? '借方' : '貸方';
}

export function validateEntry(entry, rolledAmount) {
  const errors = [];
  if (!entry.debits.length || !entry.credits.length) errors.push('借方と貸方の両方に勘定科目を置いてください');
  const debitTotal = entry.debits.reduce((s, x) => s + Number(x.amount || 0), 0);
  const creditTotal = entry.credits.reduce((s, x) => s + Number(x.amount || 0), 0);
  if (debitTotal !== creditTotal) errors.push('借方と貸方の合計が一致していません');
  if (debitTotal !== rolledAmount || creditTotal !== rolledAmount) errors.push('今回の金額と仕訳金額が一致していません');
  for (const line of [...entry.debits, ...entry.credits]) {
    if (!ACCOUNT_DEFS[line.account]) errors.push(`未登録の勘定科目です: ${line.account}`);
    if (!Number.isFinite(Number(line.amount)) || Number(line.amount) <= 0) errors.push('金額は0より大きい数にしてください');
  }
  return [...new Set(errors)];
}

function signedDelta(account, amount, side) {
  const [category] = ACCOUNT_DEFS[account];
  return side === normalSide(category) ? amount : -amount;
}

export function applyEntry(ledger, entry) {
  for (const line of entry.debits) ledger[line.account] = (ledger[line.account] || 0) + signedDelta(line.account, Number(line.amount), '借方');
  for (const line of entry.credits) ledger[line.account] = (ledger[line.account] || 0) + signedDelta(line.account, Number(line.amount), '貸方');
}

export function summarize(ledger) {
  const revenue = Object.entries(ledger).reduce((s, [name, value]) => s + (ACCOUNT_DEFS[name]?.[0] === '収益' ? value : 0), 0);
  const expense = Object.entries(ledger).reduce((s, [name, value]) => s + (ACCOUNT_DEFS[name]?.[0] === '費用' ? value : 0), 0);
  const netIncome = revenue - expense;
  const equity = Object.entries(ledger).reduce((s, [name, value]) => s + (ACCOUNT_DEFS[name]?.[0] === '純資産' ? value : 0), 0);
  const assets = Object.entries(ledger).reduce((s, [name, value]) => s + (ACCOUNT_DEFS[name]?.[0] === '資産' ? value : 0), 0);
  const liabilities = Object.entries(ledger).reduce((s, [name, value]) => s + (ACCOUNT_DEFS[name]?.[0] === '負債' ? value : 0), 0);
  return { revenue, expense, netIncome, netAssets: equity + netIncome, assets, liabilities };
}

export function calculateScore(netAssets, revenue) {
  return netAssets - revenue * 2;
}

export function isBlackProfitInsolvent(cash, liabilitiesDue, netIncome) {
  return netIncome > 0 && cash < liabilitiesDue;
}
