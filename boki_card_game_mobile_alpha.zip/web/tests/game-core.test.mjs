import test from 'node:test';
import assert from 'node:assert/strict';
import {
  rollAmount,
  calculateScore,
  isBlackProfitInsolvent,
  normalSide,
  validateEntry,
  applyEntry,
  summarize,
} from '../src/game-core.mjs';

test('サイコロ金額は1〜10 × 1〜4 × 1000', () => {
  assert.equal(rollAmount(1, 1), 1000);
  assert.equal(rollAmount(10, 4), 40000);
});

test('サイコロの範囲外は拒否する', () => {
  assert.throws(() => rollAmount(0, 1));
  assert.throws(() => rollAmount(10, 5));
});

test('勘定科目の通常残高側を返す', () => {
  assert.equal(normalSide('資産'), '借方');
  assert.equal(normalSide('負債'), '貸方');
  assert.equal(normalSide('純資産'), '貸方');
  assert.equal(normalSide('収益'), '貸方');
  assert.equal(normalSide('費用'), '借方');
});

test('借方と貸方の合計が一致した仕訳を受け入れる', () => {
  const entry = {
    debits: [{ account: '現金', amount: 10000 }],
    credits: [{ account: '資本金', amount: 10000 }],
  };
  assert.deepEqual(validateEntry(entry, 10000), []);
});

test('金額不一致を検出する', () => {
  const entry = {
    debits: [{ account: '現金', amount: 9000 }],
    credits: [{ account: '資本金', amount: 10000 }],
  };
  assert.match(validateEntry(entry, 10000).join('\n'), /一致/);
});

test('仕訳を帳簿へ反映すると残高が変わる', () => {
  const ledger = { 現金: 100000, 資本金: 100000 };
  applyEntry(ledger, {
    debits: [{ account: '現金', amount: 20000 }],
    credits: [{ account: '資本金', amount: 20000 }],
  });
  assert.equal(ledger.現金, 120000);
  assert.equal(ledger.資本金, 120000);
});

test('収益と費用から純利益、純利益を含めて純資産を計算する', () => {
  const ledger = { 現金: 120000, 資本金: 100000, 売上: 30000, 仕入: 10000 };
  const summary = summarize(ledger);
  assert.equal(summary.netIncome, 20000);
  assert.equal(summary.netAssets, 120000);
  assert.equal(calculateScore(summary.netAssets, summary.revenue), 60000);
});

test('黒字でも支払うべき負債を現金で払えないなら黒字倒産', () => {
  assert.equal(isBlackProfitInsolvent(10000, 20000, 5000), true);
  assert.equal(isBlackProfitInsolvent(30000, 20000, 5000), false);
  assert.equal(isBlackProfitInsolvent(10000, 20000, 0), false);
});
