import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
test('スマホ版の必須ファイルが揃っている', () => {
  for (const file of ['index.html','style.css','app.mjs','src/game-core.mjs','manifest.webmanifest','sw.js']) assert.equal(fs.existsSync(path.join(root,file)), true, file);
});
test('HTMLは日本語UIとモバイルviewportを持つ', () => {
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(html,/lang="ja"/); assert.match(html,/viewport/); assert.match(html,/サイコロを振る/); assert.match(html,/仕訳を確定する/); assert.match(html,/manifest.webmanifest/); assert.match(html,/serviceWorker/);
});
